package com.eiga.djob.model

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

data class GalleryData(
    @DrawableRes val imageResourceId: Int
)