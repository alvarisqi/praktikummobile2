package com.eiga.mydiceroller

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val acak: Button = findViewById(R.id.roll)
        val img1: ImageView = findViewById(R.id.gambar1)
        val img2: ImageView = findViewById(R.id.gambar2)

        img1.setImageResource(R.drawable.empty_dice)
        img2.setImageResource(R.drawable.empty_dice)

        acak.setOnClickListener {

            val dadu1 = dadu()
            val dadu2 = dadu()
            val roll1 = dadu1.roll()
            val roll2 = dadu2.roll()

            if(roll1 == roll2) {
                Toast.makeText(this, "Selamat anda dapat dadu double!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Anda belum beruntung!", Toast.LENGTH_SHORT).show()
            }

            when(roll1) {
                1 -> img1.setImageResource(R.drawable.dice_1)
                2 -> img1.setImageResource(R.drawable.dice_2)
                3 -> img1.setImageResource(R.drawable.dice_3)
                4 -> img1.setImageResource(R.drawable.dice_4)
                5 -> img1.setImageResource(R.drawable.dice_5)
                6 -> img1.setImageResource(R.drawable.dice_6)
            }

            when(roll2) {
                1 -> img2.setImageResource(R.drawable.dice_1)
                2 -> img2.setImageResource(R.drawable.dice_2)
                3 -> img2.setImageResource(R.drawable.dice_3)
                4 -> img2.setImageResource(R.drawable.dice_4)
                5 -> img2.setImageResource(R.drawable.dice_5)
                6 -> img2.setImageResource(R.drawable.dice_6)
            }
        }
    }
}

class dadu {
    fun roll(): Int {
        return (1..6).random()
    }
}